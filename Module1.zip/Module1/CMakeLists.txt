cmake_minimum_required(VERSION 3.30)
project(Module1)

set(CMAKE_CXX_STANDARD 20)

add_executable(Module1 main.cpp)
