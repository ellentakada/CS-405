// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <utility>

// custom exception class
class customException : public std::exception {
private:
    std::string message;

public:
    // constructor
    explicit customException(std::string  message) : message(std::move(message)) {}

    // what returns a message
    std::string what() {
        return message;
    }
};

bool do_even_more_custom_application_logic(bool trigger=false)
{
    // TODO: Throw any standard exception
    if (trigger) {
        throw std::exception();
    }
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    std::cout << "Running Custom Application Logic." << std::endl;

    std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    try {
        do_even_more_custom_application_logic(true);
    } catch (const std::exception& ex) {
        std::cout << "Exception thrown: " << ex.what() << std::endl;
    }

    std::cout << "Leaving Custom Application Logic." << std::endl;

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    throw customException("500");
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    if (den == 0) {
        throw std::invalid_argument("Division Error, divide by zero");
    }

    return (num / den);
}

void do_division()
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    auto result = 0.0;

    try {
        result = divide(numerator, denominator);
    } catch (std::exception& ex) {
        // throw customException(ex.what());
        std::cout << ex.what() << std::endl;
    }

    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console.

    try {
        do_division();
        do_custom_application_logic();
    } catch (customException& e) {
        // Catch custom exceptions
        std::cout <<  "Custom Exception thrown: " << e.what() << std::endl;
    } catch (const std::exception& e) {
        // Catch standard exceptions
        std::cout <<  "Exception thrown: " << e.what() << std::endl;
    } catch (...) {
        // Catch any other exceptions
        std::cout << "Caught an unknown exception!" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu