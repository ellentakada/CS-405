cmake_minimum_required(VERSION 3.30)
project(Module2_1)

set(CMAKE_CXX_STANDARD 20)

add_executable(Module2_1 SQLInjection.cpp
        sqlite3.c
        sqlite3.h
)
